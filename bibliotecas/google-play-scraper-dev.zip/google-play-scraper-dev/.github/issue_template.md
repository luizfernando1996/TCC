<!-- 
Before filing a bug please make sure to search the open issues
to make sure it hasn't already been reported:

https://github.com/facundoolano/google-play-scraper/issues

If you're reporting an error, please provide the following information. Issue without these details 
will be closed. Non error related questions can ommit this.
-->

* Operating System:
* Node version:
* google-play-scraper version:

### Description: 
Describe your issue here

### Example code:
```js
// Put code to reproduce the issue here
```

### Error message:

```
Put error message here
```
